$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0

$docPath = (Resolve-Path "docs\01_Project_Description.docx").Path
$pdfPath = [System.IO.Path]::ChangeExtension($docPath, ".export.pdf")

try {
    Write-Output "Opening: $docPath"
    $doc = $word.Documents.Open($docPath, $false, $true)
    Write-Output "Exporting to: $pdfPath"
    # wdExportFormatPDF = 17
    $doc.ExportAsFixedFormat($pdfPath, 17)
    $doc.Close(0) # wdDoNotSaveChanges = 0
    Write-Output "Export complete!"
} catch {
    Write-Output "Error: $_"
} finally {
    $word.Quit()
}

if (Test-Path $pdfPath) {
    Write-Output "PDF created successfully! Size: $(Get-Item $pdfPath).Length bytes"
    Remove-Item $pdfPath
}
